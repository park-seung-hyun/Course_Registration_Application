declare const _default: (string | string[])[][];
export default _default;
