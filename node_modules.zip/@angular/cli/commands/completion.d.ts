export interface CompletionCommandOptions {
    all?: boolean;
    bash?: boolean;
    zsh?: boolean;
}
declare const CompletionCommand: any;
export default CompletionCommand;
