export declare class InsertConcatAssetsWebpackPlugin {
    private entryNames;
    private insertAfter;
    constructor(entryNames: string[]);
    apply(compiler: any): void;
}
